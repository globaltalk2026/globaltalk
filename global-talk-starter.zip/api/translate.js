export default async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).json({ error: "Gunakan POST." });
  const { text, sourceLang, targetLang } = req.body || {};
  if (typeof text !== "string" || !text.trim() || text.length > 2000)
    return res.status(400).json({ error: "Teks wajib diisi (maksimal 2000 karakter)." });
  if (!targetLang || !/^[a-z]{2,3}(-[A-Z]{2})?$/.test(targetLang))
    return res.status(400).json({ error: "Kode bahasa tujuan tidak valid." });
  const apiKey = process.env.GOOGLE_TRANSLATE_API_KEY;
  if (!apiKey) return res.status(500).json({ error: "Environment variable GOOGLE_TRANSLATE_API_KEY belum dipasang di Vercel." });
  try {
    const payload = { q: text, target: targetLang, format: "text" };
    if (sourceLang) payload.source = sourceLang;
    const upstream = await fetch("https://translation.googleapis.com/language/translate/v2?key=" + encodeURIComponent(apiKey), {
      method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload)
    });
    const data = await upstream.json();
    if (!upstream.ok) return res.status(502).json({ error: data.error?.message || "Layanan terjemahan menolak permintaan." });
    return res.status(200).json({ translatedText: data.data.translations[0].translatedText });
  } catch (e) {
    return res.status(500).json({ error: "Terjadi kesalahan pada layanan terjemahan." });
  }
}
