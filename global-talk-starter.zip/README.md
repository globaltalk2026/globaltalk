# GLOBAL TALK starter

Prototype chat realtime Firebase + translation teks via Google Cloud Translation API.

## Setup
1. Buat project Google Cloud, aktifkan Cloud Translation API, dan siapkan API key.
2. Deploy folder ini ke Vercel.
3. Di Vercel Project Settings > Environment Variables, tambahkan `GOOGLE_TRANSLATE_API_KEY`.
4. Di Firebase Console > Authentication > Sign-in method, aktifkan Anonymous.
5. Di Firebase Realtime Database > Rules, tempel isi `database.rules.json`, lalu Publish.
6. Deploy ulang setelah mengatur environment variable.

## Tes dua arah
Kedua pengguna membuka URL yang sama dan memasukkan kode ruang yang sama.
Pengguna Indonesia: Bahasa Anda = Indonesia, Terjemahkan untuk penerima = Jepang.
Pengguna Jepang: Bahasa Anda = Jepang, Terjemahkan untuk penerima = Indonesia.

## Batas prototype
- Chat teks realtime dan terjemahan teks disediakan.
- Video call belum diaktifkan; tombolnya hanya penanda tahap WebRTC.
- Terjemahan suara/video real-time belum tersedia.
- Aturan ini hanya membatasi akses untuk pengguna yang login anonim. Belum ada undangan/keanggotaan ruang, moderasi, rate limiting, atau proteksi spam. Jangan gunakan untuk data sensitif atau peluncuran publik sebelum pengamanan lanjutan.
- API key Firebase di frontend memang konfigurasi client; kunci Google Translation disimpan di server Vercel, jangan ditaruh di HTML.
